// get the modal element
var modal= document.getElementById('simpleModal');
//get open modal button
var b1= document.getElementById('b1');
//get close button
var closeb1 =document.getElementsByClassName('closeb1')[0];
function openModal(){
	  modal.style.display='block';
}
//function to close the modal
function closeModal(){
	  modal.style.display='none';
}
//function to close the modal if outside click
function clickOutside(e){
	if(e.target == modal){
	  modal.style.display='none';
	}
}
//listen for openclick
b1.addEventListener('click',openModal);
//listen for closeclick
closeb1.addEventListener('click',closeModal);
//listen for outside click
window.addEventListener('click',clickOutside);
//function to open the modal

var low=0, high=10;
var loadedData = [];

const changeTable = (s) => {
	var table = document.getElementById("whole-table");
	while(table.rows.length>1){
			table.deleteRow(1);	
	}
	let temp=0;
	for(let idx=low; idx<high && idx<loadedData.length; idx++){
			var rowk = table.insertRow(temp+1);
			var cell1 = rowk.insertCell(0);
			var cell2 = rowk.insertCell(1);
			var cell3 = rowk.insertCell(2);
			var cell4 = rowk.insertCell(3);
			var cell5 = rowk.insertCell(4);
			var cell6 = rowk.insertCell(5);
			var cell7 = rowk.insertCell(6);
			var cell8 = rowk.insertCell(7);
			cell1.innerHTML = "c";
			cell2.innerHTML = loadedData[idx].name_customer;
			cell3.innerHTML = loadedData[idx].cust_number;
			cell4.innerHTML = loadedData[idx].invoice_id;
			cell5.innerHTML = loadedData[idx].total_open_amount;
			cell6.innerHTML = loadedData[idx].due_in_date;
			cell7.innerHTML = loadedData[idx].delay;
			cell8.innerHTML = "Note";
			temp++;
	}
	}
fetch("http://localhost:8081/H2HBABBA2524/user_servelet").then(res => res.json()).then(data => {
	
	
	
});

