package com.higradius;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class f {
    public static void main(String[] args) throws Exception {
    	Class.forName("com.mysql.jdbc.Driver");
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/invoicedb","root","aaiisshhaannyyaa");
    	
    	Statement st=con.createStatement();
    	ResultSet rs=st.executeQuery("select * from mytable where key_0=4");
    	
    	rs.next();
    	int document_create_date1_month=rs.getInt("document_create_date1_month");
    	int due_in_date_day=rs.getInt("due_in_date_day");
    	
    	System.out.print(document_create_date1_month+" "+due_in_date_day);
    	st.close();
    	con.close();
    }
}
