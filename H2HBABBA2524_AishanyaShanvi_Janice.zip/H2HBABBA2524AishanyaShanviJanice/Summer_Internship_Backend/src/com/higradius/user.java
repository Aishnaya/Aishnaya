package com.higradius;

import java.sql.Date;

public class user {
	private int key_0;
	private String name_customer;
	private String cust_number;
	private Double invoice_id;
	private Double total_open_amount;
	private Date due_in_date;
	private long delay;
	public int getKey_0() {
		return key_0;
	}
	public void setKey_0(int key_0) {
		this.key_0 = key_0;
	}
	public String getName_customer() {
		return name_customer;
	}
	public void setName_customer(String name_customer) {
		this.name_customer = name_customer;
	}
	public String getCust_number() {
		return cust_number;
	}
	public void setCust_number(String cust_number) {
		this.cust_number = cust_number;
	}
	public Double getInvoice_id() {
		return invoice_id;
	}
	public void setInvoice_id(Double invoice_id) {
		this.invoice_id = invoice_id;
	}
	public Double getTotal_open_amount() {
		return total_open_amount;
	}
	public void setTotal_open_amount(Double total_open_amount) {
		this.total_open_amount = total_open_amount;
	}
	public Date getDue_in_date() {
		return due_in_date;
	}
	public void setDue_in_date(Date due_in_date) {
		this.due_in_date = due_in_date;
	}
	public long getDelay() {
		return delay;
	}
	public void setDelay(long delay) {
		this.delay = delay;
	}
	
} 