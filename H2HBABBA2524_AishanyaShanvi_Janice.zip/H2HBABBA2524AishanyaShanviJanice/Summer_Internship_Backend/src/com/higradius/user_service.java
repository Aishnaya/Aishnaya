package com.higradius;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class user_service {
	static final String JDBC_Driver ="com.mysql.jdbc.Driver";
	static final String DB_url ="jdbc:mysql://localhost/invoicedb";
	static final String user ="root";
    static final String password ="aaiisshhaannyyaa";
    
	public List<user> getAllTables(){
		Connection conn = null;
		Statement stat = null;
		
		List<user> fetchedTable = new ArrayList<user>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(DB_url,user,password);
			stat = conn.createStatement();
			ResultSet rs= stat.executeQuery("Select * from mytable");
			
			while(rs.next()) {
				user table=new user();
				table.setName_customer(rs.getString("name_customer"));
				table.setCust_number(rs.getString("cust_number"));
				table.setInvoice_id(rs.getDouble("invoice_id"));
				table.setTotal_open_amount(rs.getDouble("total_open_amount"));
				table.setDue_in_date(rs.getDate("due_in_date"));
				table.setDelay(rs.getLong("delay"));
				fetchedTable.add(table);
			}
		}
		catch(SQLException se) {
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
	}
	finally {
		try {
			   if(stat!=null)
			   stat.close();
		      }
		  catch(SQLException se2) {}
		try {
			if(conn!=null)
			conn.close();	
		    }
		catch(Exception e) {
				e.printStackTrace();
		} }
   return fetchedTable;
} }
